#!/bin/bash
mkdir -p output
echo "hello from solution" > output/result.txt
