#!/bin/bash
pytest -q --tb=short -rA --disable-warnings --maxfail=1
