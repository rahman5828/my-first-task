import os
import subprocess

def test_solution_exists():
    assert os.path.exists("solution.sh")

def test_solution_executable():
    assert os.access("solution.sh", os.X_OK)

def test_run_solution_creates_output():
    # ensure clean state
    try:
        if os.path.exists("output/result.txt"):
            os.remove("output/result.txt")
    except Exception:
        pass
    rc = subprocess.call(["bash", "solution.sh"])
    assert rc == 0

def test_output_file_created():
    assert os.path.exists("output/result.txt")

def test_output_file_content():
    with open("output/result.txt", "r") as f:
        content = f.read()
    assert "hello from solution" in content

def test_run_tests_sh_exists_and_executable():
    assert os.path.exists("run-tests.sh") and os.access("run-tests.sh", os.X_OK)
